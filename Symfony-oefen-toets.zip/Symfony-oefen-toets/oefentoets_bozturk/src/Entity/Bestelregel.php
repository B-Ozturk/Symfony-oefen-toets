<?php

namespace App\Entity;

use App\Repository\BestelregelRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: BestelregelRepository::class)]
class Bestelregel
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column]
    private ?int $aantal = null;

    #[ORM\ManyToOne(inversedBy: 'bestelregels')]
    private ?Bestelling $Bestelling = null;

    #[ORM\ManyToOne(inversedBy: 'bestelregels')]
    private ?Pizza $Pizza = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getAantal(): ?int
    {
        return $this->aantal;
    }

    public function setAantal(int $aantal): self
    {
        $this->aantal = $aantal;

        return $this;
    }

    public function getBestelling(): ?Bestelling
    {
        return $this->Bestelling;
    }

    public function setBestelling(?Bestelling $Bestelling): self
    {
        $this->Bestelling = $Bestelling;

        return $this;
    }

    public function getPizza(): ?Pizza
    {
        return $this->Pizza;
    }

    public function setPizza(?Pizza $Pizza): self
    {
        $this->Pizza = $Pizza;

        return $this;
    }
}
