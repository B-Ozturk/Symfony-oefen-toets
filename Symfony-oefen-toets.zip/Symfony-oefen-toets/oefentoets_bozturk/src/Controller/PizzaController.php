<?php

namespace App\Controller;

use App\Repository\BestellingRepository;
use App\Repository\BestelregelRepository;
use App\Repository\KlantRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class PizzaController extends AbstractController
{
    #[Route('/', name: 'home')]
    public function index(KlantRepository $klantRepository): Response
    {
        $klanten = $klantRepository->findAll();

        return $this->render('pizza/index.html.twig', [
            'klanten' => $klanten,
        ]);
    }


}
